package client;

import javax.naming.InitialContext;

import javax.ejb.*;

import java.util.Collection;
import java.util.List;

import ejb.Test;
import entity.*;

public class JavaClient {

    public static void main(String args[]) {

        try {

            InitialContext ic = new InitialContext();
            Test sb = (Test) ic.lookup("ejb.Test");

        System.out.println("Inserting Customer and Orders... " + sb.testInsert());

        // Test query and navigation
        System.out.println("Verifying that all are inserted... " + sb.verifyInsert());

        // Get a detached instance 
        Customer c = sb.findCustomer("Joe Smith");

        // Remove all entities
        System.out.println("Removing all... " + sb.testDelete(c));

        // Query the results
        System.out.println("Verifying that all are removed... " + sb.verifyDelete());

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}

